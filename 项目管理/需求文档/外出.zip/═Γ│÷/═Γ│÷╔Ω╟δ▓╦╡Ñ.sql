prompt Importing table smtsystem.t_sys_entitymenu...
set feedback off
set define off

insert into smtsystem.t_sys_entitymenu (ENTITYMENUID, SYSTEMTYPE, ENTITYNAME, ENTITYCODE, HASSYSTEMMENU, SUPERIORID, MENUCODE, ORDERNUMBER, MENUNAME, MENUICONPATH, URLADDRESS, REMARK, CREATEUSER, CREATEDATE, UPDATEUSER, UPDATEDATE, CHILDSYSTEMNAME, ISAUTHORITY, HELPTITLE, HELPFILEPATH)
values ('E88242EE07DE3DBAE04010AC090151DE', '0', '�������', 'T_HR_EMPLOYEEOUTAPPLIECRECORD', '1', 'b8eaca3f-d648-4477-bc32-4ac3c695001b', 'T_HR_EMPLOYEEOUTAPPLIECRECORD', 0, '�������', null, '[mvc]HRM/OutApply/index', '�������', null, to_date('07-05-2013 15:56:34', 'dd-mm-yyyy hh24:mi:ss'), null, null, null, '1', null, null);

insert into smtsystem.t_sys_entitymenu (ENTITYMENUID, SYSTEMTYPE, ENTITYNAME, ENTITYCODE, HASSYSTEMMENU, SUPERIORID, MENUCODE, ORDERNUMBER, MENUNAME, MENUICONPATH, URLADDRESS, REMARK, CREATEUSER, CREATEDATE, UPDATEUSER, UPDATEDATE, CHILDSYSTEMNAME, ISAUTHORITY, HELPTITLE, HELPFILEPATH)
values ('E88242EE07DF3DBAE04010AC090151DE', '0', '�Ž���¼', 'T_HR_ACCESSRECORD', '1', 'b8eaca3f-d648-4477-bc32-4ac3c695001b', 'T_HR_ACCESSRECORD', 0, '�Ž���¼', null, '[mvc]HRM/AccessRecord/Index', '�Ž���¼', '4e09e67d-6e1b-41d6-b3ea-ad351ced5a2e', to_date('26-03-2013 16:39:55', 'dd-mm-yyyy hh24:mi:ss'), null, to_date('11-04-2013 16:40:18', 'dd-mm-yyyy hh24:mi:ss'), null, '1', null, null);

prompt Done.
