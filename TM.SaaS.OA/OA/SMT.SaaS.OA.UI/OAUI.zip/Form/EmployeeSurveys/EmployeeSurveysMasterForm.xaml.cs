﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SMT.SaaS.OA.UI.Form.EmployeeSurveys
{
    public partial class EmployeeSurveysMasterForm : BaseForm
    {
        public EmployeeSurveysMasterForm()
        {
            InitializeComponent();
        }

        private void textQuestion_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void questionOperation_Click(object sender, RoutedEventArgs e)
        {

        }

        private void textAnswer_KeyDown(object sender, KeyEventArgs e)
        {

        }

       
    }
}

