﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SMT.SaaS.OA.UI.UserControls.Surveys.SatisfactionChildWindow.GrandsonWindow
{
    public partial class ShowSatisfactioningResult : UserControl
    {
        public ShowSatisfactioningResult()
        {
            InitializeComponent();
        }
    }
}
